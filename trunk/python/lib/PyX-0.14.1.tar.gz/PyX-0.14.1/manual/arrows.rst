
.. _arrows:

*******************************
Appendix: Arrows in deco module
*******************************

.. _fig_arrows:
.. figure:: arrows.*
   :align:  center

   Arrows in deco module

