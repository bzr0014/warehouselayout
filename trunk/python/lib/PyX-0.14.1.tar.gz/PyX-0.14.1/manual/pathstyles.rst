
.. module:: style
.. _pathstyles:

*********************
Appendix: path styles
*********************

.. _fig_pathstyles:
.. figure:: pathstyles.*
   :align:  center

   path styles

