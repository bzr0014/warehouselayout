.. pyxfaq documentation master file, created by
   sphinx-quickstart on Sun Jun 12 16:54:07 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Some frequently and not so frequently asked questions about PyX
===============================================================

.. topic:: Acknowledgements

   The following persons have in one way or the other, e.g. by asking good questions or providing answers,
   contributed to this FAQ: Walter Brisken, Alejandro Gaita-Arinyo, Pierre Joyot, Jörg Lehmann, John Owens, 
   Michael Schindler, Gerhard Schmid, André Wobst.


.. toctree::
   :maxdepth: -1

   general_aspects_pyx
   python
   general_aspects_plotting
   plotting_graphs
   other_plotting
   tex_latex
